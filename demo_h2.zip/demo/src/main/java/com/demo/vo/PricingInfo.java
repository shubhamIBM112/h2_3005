package com.demo.vo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"summary",
"pricingExpression",
"currencyConversionRate",
"effectiveTime"
})
public class PricingInfo {

@JsonProperty("summary")
private String summary;
@JsonProperty("pricingExpression")
private PricingExpression pricingExpression;
@JsonProperty("currencyConversionRate")
private Integer currencyConversionRate;
@JsonProperty("effectiveTime")
private String effectiveTime;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("summary")
public String getSummary() {
return summary;
}

@JsonProperty("summary")
public void setSummary(String summary) {
this.summary = summary;
}

@JsonProperty("pricingExpression")
public PricingExpression getPricingExpression() {
return pricingExpression;
}

@JsonProperty("pricingExpression")
public void setPricingExpression(PricingExpression pricingExpression) {
this.pricingExpression = pricingExpression;
}

@JsonProperty("currencyConversionRate")
public Integer getCurrencyConversionRate() {
return currencyConversionRate;
}

@JsonProperty("currencyConversionRate")
public void setCurrencyConversionRate(Integer currencyConversionRate) {
this.currencyConversionRate = currencyConversionRate;
}

@JsonProperty("effectiveTime")
public String getEffectiveTime() {
return effectiveTime;
}

@JsonProperty("effectiveTime")
public void setEffectiveTime(String effectiveTime) {
this.effectiveTime = effectiveTime;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
