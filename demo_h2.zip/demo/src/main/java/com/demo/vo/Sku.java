package com.demo.vo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"name",
"skuId",
"description",
"category",
"serviceRegions",
"pricingInfo",
"serviceProviderName"
})
public class Sku {

@JsonProperty("name")
private String name;
@JsonProperty("skuId")
private String skuId;
@JsonProperty("description")
private String description;
@JsonProperty("category")
private Category category;
@JsonProperty("serviceRegions")
private List<String> serviceRegions = null;
@JsonProperty("pricingInfo")
private List<PricingInfo> pricingInfo = null;
@JsonProperty("serviceProviderName")
private String serviceProviderName;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("name")
public String getName() {
return name;
}

@JsonProperty("name")
public void setName(String name) {
this.name = name;
}

@JsonProperty("skuId")
public String getSkuId() {
return skuId;
}

@JsonProperty("skuId")
public void setSkuId(String skuId) {
this.skuId = skuId;
}

@JsonProperty("description")
public String getDescription() {
return description;
}

@JsonProperty("description")
public void setDescription(String description) {
this.description = description;
}

@JsonProperty("category")
public Category getCategory() {
return category;
}

@JsonProperty("category")
public void setCategory(Category category) {
this.category = category;
}

@JsonProperty("serviceRegions")
public List<String> getServiceRegions() {
return serviceRegions;
}

@JsonProperty("serviceRegions")
public void setServiceRegions(List<String> serviceRegions) {
this.serviceRegions = serviceRegions;
}

@JsonProperty("pricingInfo")
public List<PricingInfo> getPricingInfo() {
return pricingInfo;
}

@JsonProperty("pricingInfo")
public void setPricingInfo(List<PricingInfo> pricingInfo) {
this.pricingInfo = pricingInfo;
}

@JsonProperty("serviceProviderName")
public String getServiceProviderName() {
return serviceProviderName;
}

@JsonProperty("serviceProviderName")
public void setServiceProviderName(String serviceProviderName) {
this.serviceProviderName = serviceProviderName;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
