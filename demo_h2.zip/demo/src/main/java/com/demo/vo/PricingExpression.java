package com.demo.vo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"usageUnit",
"usageUnitDescription",
"baseUnit",
"baseUnitDescription",
"baseUnitConversionFactor",
"displayQuantity",
"tieredRates"
})
public class PricingExpression {

@JsonProperty("usageUnit")
private String usageUnit;
@JsonProperty("usageUnitDescription")
private String usageUnitDescription;
@JsonProperty("baseUnit")
private String baseUnit;
@JsonProperty("baseUnitDescription")
private String baseUnitDescription;
@JsonProperty("baseUnitConversionFactor")
private Long baseUnitConversionFactor;
@JsonProperty("displayQuantity")
private Integer displayQuantity;
@JsonProperty("tieredRates")
private List<TieredRate> tieredRates = null;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("usageUnit")
public String getUsageUnit() {
return usageUnit;
}

@JsonProperty("usageUnit")
public void setUsageUnit(String usageUnit) {
this.usageUnit = usageUnit;
}

@JsonProperty("usageUnitDescription")
public String getUsageUnitDescription() {
return usageUnitDescription;
}

@JsonProperty("usageUnitDescription")
public void setUsageUnitDescription(String usageUnitDescription) {
this.usageUnitDescription = usageUnitDescription;
}

@JsonProperty("baseUnit")
public String getBaseUnit() {
return baseUnit;
}

@JsonProperty("baseUnit")
public void setBaseUnit(String baseUnit) {
this.baseUnit = baseUnit;
}

@JsonProperty("baseUnitDescription")
public String getBaseUnitDescription() {
return baseUnitDescription;
}

@JsonProperty("baseUnitDescription")
public void setBaseUnitDescription(String baseUnitDescription) {
this.baseUnitDescription = baseUnitDescription;
}

@JsonProperty("baseUnitConversionFactor")
public Long getBaseUnitConversionFactor() {
return baseUnitConversionFactor;
}

@JsonProperty("baseUnitConversionFactor")
public void setBaseUnitConversionFactor(Long baseUnitConversionFactor) {
this.baseUnitConversionFactor = baseUnitConversionFactor;
}

@JsonProperty("displayQuantity")
public Integer getDisplayQuantity() {
return displayQuantity;
}

@JsonProperty("displayQuantity")
public void setDisplayQuantity(Integer displayQuantity) {
this.displayQuantity = displayQuantity;
}

@JsonProperty("tieredRates")
public List<TieredRate> getTieredRates() {
return tieredRates;
}

@JsonProperty("tieredRates")
public void setTieredRates(List<TieredRate> tieredRates) {
this.tieredRates = tieredRates;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}


}
