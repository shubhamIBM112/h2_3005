package com.demo.utility;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class HttpExternalConnection {

	@Autowired
	private RestTemplate restTemplate;
	
	public String sendAndReceiveGet(String url)  {
		System.out.println(url);
		HttpURLConnection con = null;
		BufferedReader bufferReader = null;
		StringBuilder builder = null;
		
		try{
			URL requestUrl = new URL(url);
			con = (HttpURLConnection)requestUrl.openConnection();
			con.setRequestMethod("GET");
			con.setDoInput(true);
			con.setDoOutput(true);
			bufferReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			builder = new StringBuilder();
			while ((inputLine = bufferReader.readLine()) != null) {
				builder.append(inputLine);
			}
			bufferReader.close();
			con.disconnect();
		}catch(Exception e){
			
		}return builder.toString();
	}
	
}
