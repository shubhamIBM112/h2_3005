package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.demo.utility.HttpExternalConnection;
import com.demo.vo.Sku;
import com.demo.vo.TieredRate;
import com.demo.vo.Vo;
import com.fasterxml.jackson.core.type.TypeReference;

@RestController
public class ParseAndSaveToDB {


	@Autowired
	ObjectMapper mapper;
	@Autowired
	JdbcTemplate jdbcTemplate;

	@GetMapping("/home")
	public void checkMethod(){
		System.out.println("Hello");
	}

	@PostMapping("/saveToDb")
	public void saveDataInDb(){
		String url = "https://cloudbilling.googleapis.com/v1/services/6F81-5844-456A/skus?key=AIzaSyD9XNBAF4BrEhgL47t3P7FmPTF0EAvArnY";
		HttpExternalConnection httpExternalConnection = new HttpExternalConnection();
		String output = httpExternalConnection.sendAndReceiveGet(url);
		Vo vo = new Vo();
		System.out.println(output);
		try{
			if(output!=""){
				mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
				vo =mapper.readValue(output, new TypeReference<Vo>(){
				});
			}}catch(Exception e){
				e.printStackTrace();
			}

		System.out.println(vo.getNextPageToken());

		List<Sku> skuList = vo.getSkus();
		int i = 0;
		for(Sku sk : skuList){
			i++;
			
			 insert(sk);
			 
		}
		System.out.println("Insert successful");
		if(vo.getNextPageToken()!=""){
			System.out.println("token not blank line 58");
			//getAllData(vo.getNextPageToken());
		}

	}




	public int insert(Sku sku) {

		
		int a =0;
		if(!sku.getPricingInfo().get(0).getPricingExpression().getTieredRates().isEmpty()){
		 a = jdbcTemplate.update("insert into GCP (name,skuId,description,categoryserviceDisplayName,categoryresourceFamily,categoryresourceGroup,categoryusageType,serviceRegions0,pricingInfo0summary,pricingInfo0pricingExpressionusageUnit,pricingInfo0pricingExpressionusageUnitDescription,pricingInfo0pricingExpressionbaseUnit,pricingInfo0pricingExpressionbaseUnitDescription,pricingInfo0pricingExpressionbaseUnitConversionFactor,pricingInfo0pricingExpressiondisplayQuantity,pricingInfo0pricingExpressiontieredRates0startUsageAmount,pricingInfo0pricingExpressiontieredRates0unitPricecurrencyCode,pricingInfo0pricingExpressiontieredRates0unitPriceunits,pricingInfo0pricingExpressiontieredRates0unitPricenanos,pricingInfo0currencyConversionRate,pricingInfo0effectiveTime,serviceProviderName) " + "values(?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?, ?)",
        new Object[] {
            sku.getName(),sku.getSkuId(),sku.getDescription(),sku.getCategory().getServiceDisplayName(),sku.getCategory().getResourceFamily(),sku.getCategory().getResourceGroup(),sku.getCategory().getUsageType(),sku.getServiceRegions().get(0),sku.getPricingInfo().get(0).getSummary(),sku.getPricingInfo().get(0).getPricingExpression().getUsageUnit(),sku.getPricingInfo().get(0).getPricingExpression().getUsageUnitDescription(),sku.getPricingInfo().get(0).getPricingExpression().getBaseUnit(),sku.getPricingInfo().get(0).getPricingExpression().getBaseUnitDescription(),sku.getPricingInfo().get(0).getPricingExpression().getBaseUnitConversionFactor(),sku.getPricingInfo().get(0).getPricingExpression().getDisplayQuantity(),sku.getPricingInfo().get(0).getPricingExpression().getTieredRates().get(0).getStartUsageAmount(),sku.getPricingInfo().get(0).getPricingExpression().getTieredRates().get(0).getUnitPrice().getCurrencyCode(),sku.getPricingInfo().get(0).getPricingExpression().getTieredRates().get(0).getUnitPrice().getUnits(),sku.getPricingInfo().get(0).getPricingExpression().getTieredRates().get(0).getUnitPrice().getNanos(),sku.getPricingInfo().get(0).getCurrencyConversionRate(),sku.getPricingInfo().get(0).getEffectiveTime(),sku.getServiceProviderName()
        });
		}else{
			System.out.println("else");
			a = jdbcTemplate.update("insert into GCP (name,skuId,description,categoryserviceDisplayName,categoryresourceFamily,categoryresourceGroup,categoryusageType,serviceRegions0,pricingInfo0summary,pricingInfo0pricingExpressionusageUnit,pricingInfo0pricingExpressionusageUnitDescription,pricingInfo0pricingExpressionbaseUnit,pricingInfo0pricingExpressionbaseUnitDescription,pricingInfo0pricingExpressionbaseUnitConversionFactor,pricingInfo0pricingExpressiondisplayQuantity,pricingInfo0pricingExpressiontieredRates0startUsageAmount,pricingInfo0pricingExpressiontieredRates0unitPricecurrencyCode,pricingInfo0pricingExpressiontieredRates0unitPriceunits,pricingInfo0pricingExpressiontieredRates0unitPricenanos,pricingInfo0currencyConversionRate,pricingInfo0effectiveTime,serviceProviderName) " + "values(?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?, ?)",
			        new Object[] {
			                sku.getName(),sku.getSkuId(),sku.getDescription(),sku.getCategory().getServiceDisplayName(),sku.getCategory().getResourceFamily(),sku.getCategory().getResourceGroup(),sku.getCategory().getUsageType(),sku.getServiceRegions().get(0),sku.getPricingInfo().get(0).getSummary(),sku.getPricingInfo().get(0).getPricingExpression().getUsageUnit(),sku.getPricingInfo().get(0).getPricingExpression().getUsageUnitDescription(),sku.getPricingInfo().get(0).getPricingExpression().getBaseUnit(),sku.getPricingInfo().get(0).getPricingExpression().getBaseUnitDescription(),sku.getPricingInfo().get(0).getPricingExpression().getBaseUnitConversionFactor(),sku.getPricingInfo().get(0).getPricingExpression().getDisplayQuantity(),0,"","",0,sku.getPricingInfo().get(0).getCurrencyConversionRate(),sku.getPricingInfo().get(0).getEffectiveTime(),sku.getServiceProviderName()
			            });
		}
		return a;
	}
	
	public void getAllData(String token){
		System.out.println("in Getalldata");
		String StaticUrl = "https://cloudbilling.googleapis.com/v1/services/6F81-5844-456A/skus?key=";
		String newUrl = StaticUrl+token;
		HttpExternalConnection httpExternalConnection = new HttpExternalConnection();
		String output = httpExternalConnection.sendAndReceiveGet(newUrl);
		Vo vo = new Vo();
		System.out.println(output);
		try{
			if(output!=""){
				mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
				vo =mapper.readValue(output, new TypeReference<Vo>(){
				});
			}}catch(Exception e){
				e.printStackTrace();
			}

		System.out.println(vo.getNextPageToken());

		List<Sku> skuList = vo.getSkus();
		for(Sku sk : skuList){
			insert(sk);
		}
		if(vo.getNextPageToken()!=""){
			getAllData(vo.getNextPageToken());
		}
	}
}
